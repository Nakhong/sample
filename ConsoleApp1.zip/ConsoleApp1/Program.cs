﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1


{
    class Program
    {
        static void Main(string[] args)
        {
            //Day1 day1 = new Day1();
            //Day2 day2 = new Day2();
            Day3 day3 = new Day3();
            day3.Question1();
            //day2.Question3();
            Console.ReadKey();
        }
    }
}
